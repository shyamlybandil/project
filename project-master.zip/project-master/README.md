# project
This project is being developed as out major project.
This poject aims at providing online educational courses for students by sitting at home.
