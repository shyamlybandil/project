/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.f4.service;
import org.f4.datasource.*;
/**
 *
 * @author jarvis
 */
public class LoginFormService {
    
    
}
